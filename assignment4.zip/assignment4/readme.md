# HTML,CSS,JavaScript with Blogging Website Project

## How to run the project file

* Open the landing.js file and run with "open with live server"
* When you first run project, you will see the Home Page with last 20 datas as posts but you are not logged in here
* To see the post detail and edit, you have to log in.
* Click LogIn Button, you will reach to login page.
* In Login page , you have to fill valid username,email,password(checked with regexp). If not , you will be shown some errors when click log in button.
* when you click log in button and wait for a moment , you will reach homepage (your username and log out button will be shown)/If you click log out button , you will reach again to login page.
* When your account is logged in , you can see the post detail, edit the post and delete the posts as you wish.
* When you click "Create Post" button, a box which asked for (the imageurl,title, content) will be dropped.When you fill the data and click "create post" button ,the data (including the date and time) you filled is shown at the top of the previous posts.
* In conclusion, I've already expalined how my code works by adding comments for every detail of code in the project file.
